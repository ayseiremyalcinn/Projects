import React, { useState } from "react";
import { Button, TextField} from '@mui/material';
import axios from "axios";
import { toast } from "react-toastify";
import "./Register.css";

export default function Register(props) {
  const [modal, setModal] = useState(false);
  const [email, setEmail] = useState(null);
  const [name, setName] = useState(null);
  const [surname, setSurname] = useState(null);
  const [password, setPassword] = useState(null);

  const toggleModal = () => {
    setModal(!modal);
  };

  if(modal) {
    document.body.classList.add('active-modal')
  } else {
    document.body.classList.remove('active-modal')
  }

  function myFunction(data) {
    if (data === 201) {
      toast.success("Confirmed", { position: toast.POSITION.TOP_CENTER,autoClose: 1500, });
      toggleModal();
    } 
    else {
      toast.error("Error", { position: toast.POSITION.TOP_CENTER, autoClose: 1500,});
    }
  }
  
  function register() {

    if(email === null || email === ""){
      toast.error("Email Cannot Be Empty", { position: toast.POSITION.TOP_CENTER,autoClose: 1500, });
    }
    else if(password === null || password === ""){
      toast.error("Password Cannot Be Empty", { position: toast.POSITION.TOP_CENTER,autoClose: 1500, });
    }    
    else if(name === null || name === ""){
      toast.error("Name Cannot Be Empty", { position: toast.POSITION.TOP_CENTER,autoClose: 1500, });
    }    
    else if(surname === null || surname === ""){
      toast.error("Surname Cannot Be Empty", { position: toast.POSITION.TOP_CENTER,autoClose: 1500, });
    }
    else{
      const registered = {
        email: email,
        name: name,
        surname: surname,
        password: password,
      };

      axios
        .post("http://localhost:3001/user/adduser", registered)
        .then((response) => {myFunction(response.status)})
        .catch(function (error) {
          if (error.response) {
            toast.error("Invalid Email", {
              position: toast.POSITION.TOP_CENTER,
              autoClose: 1500,
            });
            setTimeout(() => { window.location.reload();}, 1500);
          }
      });
    setEmail(null);
    setName(null);
    setSurname(null);
    setPassword(null);
    }
  }

  return (
    <>
      <Button onClick={toggleModal} style={{width:props.width, color:'white'}}className="btn-modal">
        REGISTER
      </Button>

      {modal && (
        <div className="modal">
          <div onClick={toggleModal} className="overlay"></div>
          <div className="modal-content">
            
            <h3 style={{marginTop:'20px', color:'white'}}>REGISTER</h3>

            <TextField
              id="name"
              InputProps={{ inputProps: { min: 0, max: 100 } }}
              label="Name"
              style={{outline:'none' ,border:'none',backgroundColor:'white',width: "80%", marginLeft: "10%", marginRight: "10%",marginTop:'25px' }}
              onChange={(e) => {
                setName(e.target.value);
              }}
            />            
            <TextField
            id="surname"
            InputProps={{ inputProps: { min: 0, max: 100 } }}
            label="Surname"
            style={{outline:'none' ,border:'none',backgroundColor:'white',width: "80%", marginLeft: "10%", marginRight: "10%",marginTop:'25px' }}
            onChange={(e) => {
              setSurname(e.target.value);
            }}
          />
            <TextField
              id="email"
              InputProps={{ inputProps: { min: 0, max: 100 } }}
              label="Email"
              style={{outline:'none' ,border:'none',backgroundColor:'white',width: "80%", marginLeft: "10%", marginRight: "10%",marginTop:'25px' }}
              onChange={(e) => {
                setEmail(e.target.value);
              }}
            />
            <TextField
              id="password"
              InputProps={{ inputProps: { min: 0, max: 100 } }}
              label="Password"
              style={{outline:'none' ,border:'none',backgroundColor:'white',width: "80%", marginLeft: "10%", marginRight: "10%",marginTop:'25px' }}
              onChange={(e) => {
                setPassword(e.target.value);
              }}
            />
            <Button 
            style={{
              color:'white', 
              width: "20%", 
              marginLeft: "40%", 
              marginRight: "40%",
              marginTop:'10px'
              ,textAlign:'center' }}
              onClick={register}
              >
                REGISTER
              </Button>
          </div>
        </div>
      )}
    </>
  );
}