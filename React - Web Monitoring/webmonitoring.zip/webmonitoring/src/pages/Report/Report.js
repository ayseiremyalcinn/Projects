import React, { useEffect, useState } from 'react'
import axios from "axios";
import '../Report/Report.css'
import {
    Bar,
    BarChart,
    LineChart,
    Line,
    XAxis,
    CartesianGrid,
    Tooltip,
    ResponsiveContainer,
    YAxis,
  } from "recharts";

const Report = () => {

  const [statusList, setList] = useState([])
  const [host, setHost] = useState([])
  const [hostName, setHostName] = useState(null)

  const getStatus = async () => {
    try {
      await axios.get("http://localhost:3001/status/").then((res) => {
          setList(res.data)
        });
    } catch (err) {
      alert(err)
    }
  };

  useEffect(() => {
    getStatus();
  }, []);

  function adjustHost(index){
    setHost(statusList[index].responseTimes)
    setHostName(statusList[index].url)
    console.log(host)
  }

  console.log(host)
  console.log(statusList)

  return (
    <div className='report-main-page-container'>
        <div className='report-container' >

          <div className='report-stats'>

            <div className='button-container'>
              <select
                    onChange={(e) => {adjustHost(e.target.value);}}
                    style={{outline:'none',border:'none',width: "100%", height:'100%', backgroundColor:'transparent'}}
                  >
                    <option value="none" selected disabled hidden>Select an Host</option>
                    {statusList.map((item,i) =>
                        <option key={item._id} value={i}>
                          {item.url}
                        </option>
                    )}
                </select>
            </div>

            <div className='button-container' style={{textAlign:'center'}}>
              <div style={{marginTop:'10px'}}><h style={{color:'white', marginTop:'20px'}}>{hostName}</h></div>
            </div>
            
            

          </div>

          <div className='report-graph-container' style={{marginLeft: '1%', marginTop:'1%'}}>

            <div className="time-graph" style={{borderRadius:'10px', marginTop:'25px',marginLeft:'5%',backgroundColor:"white",width:'90%'}}>
                <div style={{textAlign:'center'}}>
                  <h3 style={{fontFamily:'Calibri', color:'#222940'}}>Response Times (ms)</h3>
                </div>
                <ResponsiveContainer width="100%" aspect={4 / 1}>
                    <LineChart data={host}>
                    <XAxis dataKey="time" hide={true}/>
                    <YAxis/>
                    <Line type="monotone" label={"Response Time"} dataKey="duration" stroke="#5550bd" />
                    <Tooltip trigger='hover' />
                    {<CartesianGrid stroke="#e0dfdf" strokeDasharray="5 5" />}
                    </LineChart>
                </ResponsiveContainer>
            </div> 

            <div className="time-graph" style={{borderRadius:'10px', marginTop:'25px',marginLeft:'5%',backgroundColor:"white",width:'90%'}}>
                <ResponsiveContainer width="100%"  aspect={4 / 1}>
                    <BarChart data={host}>
                    <XAxis dataKey="time" hide={true}/>
                    <YAxis/>
                    <Bar type="monotone" dataKey="duration" fill="#8884d8" label={{ position: 'center' }}/>
                    <Tooltip trigger='hover' />
                    </BarChart>
                </ResponsiveContainer>
            </div>             

          </div>
        </div>
    </div>
  )
}

export default Report
