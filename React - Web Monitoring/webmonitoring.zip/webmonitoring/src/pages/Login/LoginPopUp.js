import React, { useState } from "react";
import { Button, TextField} from '@mui/material';
import axios from "axios";
import { toast } from "react-toastify";
import LoginIcon from '@mui/icons-material/Login';
import "./LoginPopUp.css";

export default function LoginPopUp(props) {
  const [modal, setModal] = useState(false);
  const [email, setEmail] = useState(null);
  const [password, setPassword] = useState(null);

  const toggleModal = () => {
    setModal(!modal);
  };

  if(modal) {
    document.body.classList.add('active-modal')
  } else {
    document.body.classList.remove('active-modal')
  }

  function myFunction(data) {
    if (data === 201) {
      toast.success("Confirmed", { position: toast.POSITION.TOP_CENTER,autoClose: 1500, });
      toggleModal();
    } 
    else {
      toast.error("Error", { position: toast.POSITION.TOP_CENTER, autoClose: 1500,});
    }
  }
  
  return (
    <>
      <Button startIcon={<LoginIcon/>} onClick={toggleModal} style={{width:props.width, color:'white'}}className="btn-modal">
        Login
      </Button>

      {modal && (
        <div className="modal">
          <div onClick={toggleModal} className="overlay"></div>
          <div className="modal-content">
            
            <h3 style={{marginTop:'20px', color:'white'}}>LOGIN</h3>


            <TextField
              id="email"
              InputProps={{ inputProps: { min: 0, max: 100 } }}
              label="Email"
              style={{outline:'none' ,border:'none',backgroundColor:'white',width: "80%", marginLeft: "10%", marginRight: "10%" }}
              onChange={(e) => {
                setEmail(e.target.value);
              }}
            />
            <TextField
              id="password"
              InputProps={{ inputProps: { min: 0, max: 100 } }}
              label="Password"
              style={{outline:'none' ,border:'none',backgroundColor:'white',width: "80%", marginLeft: "10%", marginRight: "10%",marginTop:'25px' }}
              onChange={(e) => {
                setPassword(e.target.value);
              }}
            />
            <Button style={{color:'white', width: "30%", marginLeft: "35%", marginRight: "35%", marginTop:'10px',textAlign:'center' }}>Login</Button>
          </div>
        </div>
      )}
    </>
  );
}