import React, { useEffect, useState } from 'react'
import axios from "axios";
import { Button } from '@mui/material';
import {toast} from 'react-toastify'
import { Container } from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import '../SSL/SSL.css'
//import VerifiedUserIcon from '@mui/icons-material/VerifiedUser';

const SSLCheck = () => {

  const [sslList, setList] = useState([])

  const getSSL = async () => {
    try {
      await axios.get("http://localhost:3001/host/").then((res) => {
          let tempData = res.data
          tempData.sort((a, b) => (a.sslExpiration < b.sslExpiration) ? -1 : 1)
          setList(tempData)
        });
    } catch (err) {
      alert(err)
    }
  };

  useEffect(() => {
    getSSL();
  }, []);

  console.log(sslList)

  const checkNow = async () => {
    try {
      await axios.get("http://localhost:3001/sslCheck/").then((res) => {
        toast.success("Check done successfully.", {position: toast.POSITION.TOP_CENTER, });
        setTimeout(() => { window.location.reload();}, 1500);
      });
    } catch (err) {
      alert(err)
    }
    
  };

  const columns = [
    {
      field: "url",
      headerName: "URL",
      width: 250,
      sortable: false,
      disableColumnMenu: true,
    },
    {
      field: "sslExpiration",
      headerName: "SSL Certificate Remaining Days",
      width: 250,
      sortable: true,
      disableColumnMenu: true,
    },
    {
      field: "sslLastCheck",
      headerName: "SSL Certificate Last Check",
      width: 450,
      sortable: false,
      disableColumnMenu: true,      
    }
  ];

  return (
    <div className='ssl-main-page-container'>
        <div className='ssl-container' >

          <div className='stats'>

            <div className='button-container-ssl'>
              <Button onClick={checkNow} style={{flex:'1', color:'white',width :'125px'}}>CHECK NOW</Button>
            </div>

          </div>

          <div className='ssl-table' style={{padding:'20px'}}>
            <Container sx={{ 
              borderRadius:5,
              height: 500, 
              width: 1000,
              backgroundColor:'white',
              scrollbarColor:'#313d53',
              '& .low': {backgroundColor: 'lightgreen',color: '#313d53',},
              '& .moderate': {backgroundColor: 'yellow',color: '#313d53',},
              '& .high': {backgroundColor: '#ee9f91',color: '#313d53',},
              }}>
              <DataGrid
                rows={sslList}
                getRowId={(row) => row._id}
                columns={columns}
                headerHeight={50}
                hideFooter={true}
                rowHeight={45}
                disableSelectionOnClick
                getCellClassName={(params) => {
                  if (params.sslExpiration > 90) {return 'low';}
                  else if(params.sslExpiration > 45 && params.sslExpiration <= 90){return 'moderate';}
                  else if(params.sslExpiration < 46){return 'high'}
                }}
              />
            </Container>
          </div>

        </div>
    </div>
  )
}

export default SSLCheck
