import '../Home/Home.css'
import React, { useEffect, useState } from 'react'
import axios from "axios"
import {
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar
} from "recharts";


const Home = () => {

  const [uphostCount, setHostUp] = useState(0)
  const [downhostCount, setHostDown] = useState(0)
  const [midhostCount, setHostMid] = useState(0)

  const [highsslCount, setSSLHigh] = useState(0)
  const [moderatesslCount, setSSLmoderate] = useState(0)
  const [lowsslCount, setSSLLow] = useState(0)

  const [hostData, setHostData] = useState([])

  const getStatus = async () => {
    try {
      await axios.get("http://localhost:3001/status/").then((res) => {
          let tempData = res.data
          let tempup = 0
          let tempdown = 0
          let tempmid = 0
          let carrierArr = []

          tempData.forEach(element=>{

            let sum = 0;
            element.responseTimes.forEach(time=>{sum = sum + time.duration})
            carrierArr.push({
              host: element.url,
              responseTime: Math.floor((sum/(element.responseTimes.length)))
            })
          })

          tempData.forEach(element => {
            if(element.serverStatus >600){tempmid = tempmid + 1}
            else if(element.serverStatus >499){tempdown = tempdown + 1}
            else{tempup = tempup + 1}
          });

          setHostUp(tempup)
          setHostDown(tempdown)
          setHostMid(tempmid)
          setHostData(carrierArr)
        });
    } catch (err) {
      alert(err)
    }
  };

  const getSSL = async () => {
    try {
      await axios.get("http://localhost:3001/host/").then((res) => {
          let tempData = res.data
          let temphigh = 0
          let templow = 0
          let tempmoderate = 0

          tempData.forEach(element => {
            if(element.sslExpiration <= 45){temphigh = temphigh + 1}
            else if(element.sslExpiration <= 90){tempmoderate = tempmoderate + 1}
            else{templow = templow + 1}
          });

          setSSLHigh(temphigh)
          setSSLmoderate(tempmoderate)
          setSSLLow(templow)

        });
    } catch (err) {
      alert(err)
    }
  };

  useEffect(() => {
    getStatus();
    getSSL();
  }, []);

  return (
    <div className='main-page-container'>
        <div className='home-container'>
          <div className='health-stats'>

            <div className='host-status-container-home' onClick={() => {window.location.href='/health'}}>

              <h style={{color:'white', fontWeight:'600'}}>Host Status</h>
              
              <div className='up-down-counter' style={{marginBottom:'0px'}}>
                <div className='circular-counter'>
                  <div class="circle" style={{backgroundColor:'#ee9f91',fontFamily:'OpenSans', fontWeight:'600'}}>{downhostCount}</div>
                  <h style={{color:'white', fontWeight:'600',fontFamily:'OpenSans'}}>DOWN</h>
                </div>

                <div className='circular-counter' >
                  <div class="circle" style={{backgroundColor:'yellow',fontFamily:'OpenSans', fontWeight:'600'}}>{midhostCount}</div>  
                  <h style={{color:'white', fontWeight:'600',fontFamily:'OpenSans'}}>TROUBLE</h> 
                </div>

                <div className='circular-counter' >
                  <div class="circle" style={{backgroundColor:'lightgreen',fontFamily:'OpenSans', fontWeight:'600'}}>{uphostCount}</div>  
                  <h style={{color:'white', fontWeight:'600',fontFamily:'OpenSans'}}>UP</h> 
                </div>
              </div>

            </div>

            <div className='host-status-container-home' onClick={() => {window.location.href='/ssl'}}>

              <h style={{color:'white', fontWeight:'600'}}>SSL CERTIFICATE STATUS</h>

              <div className='up-down-counter' style={{marginBottom:'0px'}}>
                <div className='circular-counter'>
                  <div class="circle" style={{backgroundColor:'#ee9f91',fontFamily:'OpenSans', fontWeight:'600'}}>{highsslCount}</div>
                  <h style={{color:'white', fontWeight:'600',fontFamily:'OpenSans'}}>HIGH</h>
                </div>

                <div className='circular-counter' >
                  <div class="circle" style={{backgroundColor:'yellow',fontFamily:'OpenSans', fontWeight:'600'}}>{moderatesslCount}</div>  
                  <h style={{color:'white', fontWeight:'600',fontFamily:'OpenSans'}}>MODERATE</h> 
                </div>

                <div className='circular-counter' >
                  <div class="circle" style={{backgroundColor:'lightgreen',fontFamily:'OpenSans', fontWeight:'600'}}>{lowsslCount}</div>  
                  <h style={{color:'white', fontWeight:'600',fontFamily:'OpenSans'}}>LOW</h> 
                </div>
              </div>

            </div>

          </div>
          
          <div className="time-graph" 
          style={{borderRadius:'10px', marginTop:'25px',marginLeft:'2%',backgroundColor:"white",width:'90%'}}
          onClick={() => {window.location.href='/report'}}
          >
                <div style={{textAlign:'center'}}>
                  <h3 style={{fontFamily:'Calibri', color:'#222940'}}>Mean Response Times</h3>
                </div>
                <ResponsiveContainer width="100%" aspect={4 / 1}>
                    <BarChart data={hostData}>
                    <XAxis dataKey="host" hide={true} />
                    <YAxis/>
                    <Bar type="monotone" dataKey="responseTime" fill="#8884d8" label={{ position: 'center' }}/>
                    <Tooltip trigger='hover'/>
                    </BarChart>
                </ResponsiveContainer>
          </div>  
          
        </div>
    </div>
  )
}

export default Home
