import React, { useEffect, useState } from 'react'
import '../Health/Health.css'
import axios from "axios";
import { Button } from '@mui/material';
import {toast} from 'react-toastify'
import Modal from '../../components/PopUp/PopUp';
//import VerifiedUserIcon from '@mui/icons-material/VerifiedUser';

const Health = () => {

  const [statusList, setList] = useState([])

  const getStatus = async () => {
    try {
      await axios.get("http://localhost:3001/status/").then((res) => {
          let carrier = []
          let tempData = res.data

          tempData.sort((a, b) => (a.serverStatus > b.serverStatus) ? -1 : 1)

          while (tempData.length > 0) {
            carrier.push(tempData.splice(0,5))
          }

          setList(carrier)
        });
    } catch (err) {
      alert(err)
    }
  };

  useEffect(() => {
    getStatus();
  }, []);

  console.log(statusList)

  const checkNow = async () => {
    try {
      await axios.get("http://localhost:3001/health/").then((res) => {
        toast.success("Check done successfully.", {position: toast.POSITION.TOP_CENTER, });
        setTimeout(() => { window.location.reload();}, 3000);
      });
    } catch (err) {
      alert(err)
    }
    
  };

  return (
    <div className='health-main-page-container'>
        <div className='health-container' >

          <div className='stats'>

            <div className='button-container'>
              <Button onClick={checkNow} style={{flex:'1', color:'white',width :'125px'}}>CHECK NOW</Button>
              <Modal width = {'125px'}></Modal>
            </div>

          </div>

          <div className='tile-container' style={{marginLeft: '1%', marginTop:'1%'}}>

            {statusList.map((itemlist) => {
              return(
              <div className='tile-row' style={{display:'flex', flexDirection:'row'}}>
                {itemlist.map((item) => {
                  console.log(item)
                  if(item.serverStatus > 499 && item.serverStatus < 600){
                    return(                  
                      <div className='tile' style={{backgroundColor: '#FFCCCB'}}>
                        <div style={{marginTop:'3px'}}><h style={{color:'#222940'}}>{item.url}</h></div>
                        <div style={{marginTop:'2px'}}>
                          {item.responseTimes.length === 0
                            ?
                            <h style={{color:'#222940'}}>ms</h>                          
                            :                          
                            <h style={{color:'#222940'}}>
                            {item.responseTimes[item.responseTimes.length-1].duration} ms
                            </h>
                          }
                        </div>
                        <div style={{marginTop:'2px'}}>
                          <h style={{color:'#222940'}}>
                            {item.time.replace("GMT+0300 (GMT+03:00)", "")}
                          </h>
                        </div>
                      </div>
                    );
                  }
                  else if(item.serverStatus > 600){
                    return(                  
                      <div className='tile' style={{backgroundColor: 'yellow', fontSize:'18px'}}>
                        <div style={{marginTop:'3px'}}><h style={{color:'#222940'}}>{item.url}</h></div>
                        <div style={{marginTop:'2px'}}>
                          {item.responseTimes.length === 0
                          ?
                          <h style={{color:'#222940'}}>ms</h>                          
                          :                          
                          <h style={{color:'#222940'}}>
                          {item.responseTimes[item.responseTimes.length-1].duration} ms
                          </h>
                          }
                        </div>
                        <div style={{marginTop:'2px'}}>
                          <h style={{color:'#222940'}}>
                            {item.time.replace("GMT+0300 (GMT+03:00)", "")}
                          </h>
                        </div>
                      </div>
                    );                    
                  }
                  else{
                    return(                  
                      <div className='tile' style={{backgroundColor: 'lightgreen', fontSize:'18px'}}>
                        <div style={{marginTop:'3px'}}><h style={{color:'#222940'}}>{item.url}</h></div>
                        <div style={{marginTop:'2px'}}>
                          {item.responseTimes.length === 0
                            ?
                            <h style={{color:'#222940'}}>ms</h>                          
                            :                          
                            <h style={{color:'#222940'}}>
                            {item.responseTimes[item.responseTimes.length-1].duration} ms
                            </h>
                          }
                        </div>
                        <div style={{marginTop:'2px'}}>
                          <h style={{color:'#222940'}}>
                            {item.time.replace("GMT+0300 (GMT+03:00)", "")}
                          </h>
                        </div>
                      </div>
                    );
                  }
                })}
              </div>
              );
            })}

          </div> 
        </div>
    </div>
  )
}

export default Health
