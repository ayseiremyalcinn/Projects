import { BrowserRouter, Route, Routes } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import './App.css';
import SideBar from "./components/SideBar/SideBar";
import TopBar from "./components/TopBar/TopBar";
import Health from "./pages/Health/Health";
import SSLCheck from "./pages/SSL/SSL";
import Home from "./pages/Home/Home";
import 'react-toastify/dist/ReactToastify.css';
import Report from "./pages/Report/Report";

function App() {
  return (
    <BrowserRouter>
      
      <ToastContainer style={{justifyContent: "center"}}/>

      <TopBar/>

      <div style={{display:'flex', backgroundColor:'#222940'}}>

        <SideBar/>
        
        <Routes>
            <>
              <Route exact path="/" element={<Home />} />
              <Route exact path="/health" element={<Health />} />
              <Route exact path="/ssl" element={<SSLCheck />} />
              <Route exact path="/report" element={<Report />} />
            </>
        </Routes>

      </div>

    </BrowserRouter>
  );
}

export default App;
