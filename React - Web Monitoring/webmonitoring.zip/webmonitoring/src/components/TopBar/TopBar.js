import React from 'react'
import '../TopBar/TopBar.css'
import { Button } from '@mui/material';
const TopBar = () => {

  return (
    <div className='topbar-container'>
      <div className='topbar-logo-container'>
      <Button href="/" style={{color:'white', width:'180px', height:'60px'}}></Button>
      </div>
    </div>
  )
}

export default TopBar
