import React, { useState } from "react";
import { Button, TextField} from '@mui/material';
import "./PopUp.css";
import axios from "axios";
import { toast } from "react-toastify";

export default function Modal(props) {
  const [modal, setModal] = useState(false);
  const [host, setHost] = useState(null);

  const toggleModal = () => {
    setModal(!modal);
  };

  if(modal) {
    document.body.classList.add('active-modal')
  } else {
    document.body.classList.remove('active-modal')
  }

  function myFunction(data) {
    if (data === 201) {
      toast.success("Confirmed", { position: toast.POSITION.TOP_CENTER,autoClose: 1500, });
      toggleModal();
    } 
    else {
      toast.error("Error", { position: toast.POSITION.TOP_CENTER, autoClose: 1500,});
    }
  }
  
  const addHost = async () => {
    alert(host)

    const newHost = {
      url:host
    }
    axios
      .post("http://localhost:3001/host/addhost", newHost)
      .then((response) => myFunction(response.status))
      .catch(function (error) {
        if (error.response) {
          toast.error("Invalid Email", {
            position: toast.POSITION.TOP_CENTER,
            autoClose: 1000,
          });
        }
      });
  }

  return (
    <>
      <Button onClick={toggleModal} style={{width:props.width, color:'white'}}className="btn-modal">
        Add Monitor
      </Button>

      {modal && (
        <div className="modal">
          <div onClick={toggleModal} className="overlay"></div>
          <div className="modal-content">

            <h3 style={{marginTop:'30px', color:'white'}}>Please enter the host url you want to monitor</h3>
            <TextField
              id="hostname"
              InputProps={{ inputProps: { min: 0, max: 100 } }}
              label="Host Name"
              style={{outline:'none' ,border:'none',backgroundColor:'white',width: "80%", marginLeft: "10%", marginRight: "10%" }}
              onChange={(e) => {
                setHost(e.target.value);
              }}
            />
            <Button style={{ color:'white', width: "30%", marginLeft: "35%", marginRight: "35%", marginTop:'10px' }} onClick={addHost}>ADD</Button>
            <button className="close-modal" onClick={toggleModal}>
              X
            </button>
          </div>
        </div>
      )}
    </>
  );
}