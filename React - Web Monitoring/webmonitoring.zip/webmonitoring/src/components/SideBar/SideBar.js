import React from 'react';
import { Button } from '@mui/material';
import LogoutIcon from '@mui/icons-material/Logout';
import HomeIcon from '@mui/icons-material/Home';
import VerifiedUserIcon from '@mui/icons-material/VerifiedUser';
import BugReportIcon from '@mui/icons-material/BugReport';
import ArticleIcon from '@mui/icons-material/Article';
import MailIcon from '@mui/icons-material/Mail';
import ComputerIcon from '@mui/icons-material/Computer';
import TimerIcon from '@mui/icons-material/Timer';
import '../SideBar/SideBar.css'
import LoginPopUp from '../../pages/Login/LoginPopUp';
import Register from '../../pages/Register/Register';
const SideBar = () => {

  let loggedIn = true;

  return (
    <div className='sidebar-main'>
        <div className='sidebar-container'>


          {loggedIn === false
          ?
          <>
            <div className='sidebar-button-top'>
              <LoginPopUp/>
            </div>
            <div className='sidebar-button'>
              <Register/>
            </div>
          </>
          :
          <>
          <div className='sidebar-button-top'>
            <Button startIcon={<HomeIcon/>} href="/" style={{color:'white', fontSize:'14px'}}>Home</Button>
          </div>

          <div className='sidebar-button'>
            <Button startIcon={<VerifiedUserIcon/>} href="/health" style={{color:'white'}}>Health Check</Button>
          </div>

          <div className='sidebar-button'>
            <Button  startIcon={<BugReportIcon/>} href="/" style={{color:'white'}}>Defacement</Button>
          </div>

          <div className='sidebar-button'>
            <Button startIcon={<ComputerIcon/>} href="/" style={{color:'white'}}>Zone.h</Button>
          </div>

          <div className='sidebar-button'>
            <Button startIcon={<TimerIcon/>} href="/ssl" style={{color:'white'}}>SSL Check</Button>
          </div>

          <div className='sidebar-button'>
            <Button startIcon={<ArticleIcon/>} href="/report" style={{color:'white'}}>Report</Button>
          </div>

          <div className='sidebar-button'>
            <Button startIcon={<MailIcon/>} href="/" style={{color:'white'}}>Mail</Button>
          </div>

          <div className='sidebar-button-bottom'>
            <Button  startIcon={<LogoutIcon/>}>Exit</Button>
          </div>
          </>
          }
          
        </div>
    </div>
  )
}

export default SideBar
