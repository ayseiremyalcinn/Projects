const User = require('../models/userSchema');
const router = require("express").Router();

//Get All User Records
router.get("/", async (req, res) => {
    try {
      const orders = await User.find();
      res.status(200).json(orders);
    } catch (err) {
      res.status(500).json(err);
    }
});

//Add New User to System
router.post("/adduser", async (req, res) => {

    findMail = req.body.email;
    if(User.findOne(findMail))
    {
      const newUser = new User({
        name: req.body.name,
        surname: req.body.surname,
        password: req.body.password,
        email: req.body.email,
      });
  
      try {
        const savedUser = await newUser.save();
        res.status(201).json(savedUser);
      } catch (err) {
        res.status(500).json(err);
      }
    }
    else
    {
      res.status(500).json(err);
    }
  });


//Login to System
router.post("/login", async (req, res) => {


});
  
module.exports = router;