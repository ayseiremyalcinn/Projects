const Host = require('../models/hostSchema');
const router = require("express").Router();
const sslChecker = require('ssl-checker');

//Get All Host Records
router.get("/", async (req, res) => {
    try {
      const hosts = await Host.find();
      res.status(200).json(hosts);
    } catch (err) {
      res.status(500).json(err);
    }
});


//Add New Host to Monitor
router.post("/addhost", async (req, res) => {


  //Formatting url to fit into ssl check function
  let tempUrl = req.body.url
  tempUrl = tempUrl.replace("https://", "").replace("/", "")

  //Default expiration remaining
  let expiration = -1;

  //Check remaining days and store in temporary variable
  try{
    await sslChecker(tempUrl, { method: "GET", port: 443 }).then(function(info){console.log(info); expiration = info.daysRemaining});
  }
  catch(err){
    console.log(err)
  }

  //Create new host object
  const newHost = new Host({
    url: req.body.url,
    subdomains: [],
    sslExpiration: expiration,
    sslLastCheck:Date().toString()
  });

  //Save new host object to database
  try {
    const savedHost = await newHost.save();
    res.status(201).json(savedHost);
  } catch (err) {
    res.status(500).json(err);
  }
});

module.exports = router;