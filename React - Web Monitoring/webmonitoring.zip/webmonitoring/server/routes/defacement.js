const Defacement = require('../models/defacementSchema');
const router = require("express").Router();

//Get All Defacement Records
router.get("/", async (req, res) => {
    try {
      const defacements = await Defacement.find();
      res.status(200).json(defacements);
    } catch (err) {
      res.status(500).json(err);
    }
});


//Add New Defacement
router.post("/adddefacement", async (req, res) => {

  //Create new host object
  const newHost = new Host({
    url: req.body.url,
    hash: req.body.hash,
    lastCheck: Date().toString()
  });

  //Save new defacement object to database
  try {
    const savedDefacement = await newDefacement.save();
    res.status(201).json(savedDefacement);
  } catch (err) {
    res.status(500).json(err);
  }
});

module.exports = router;