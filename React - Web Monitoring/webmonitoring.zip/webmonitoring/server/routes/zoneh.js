const Zoneh = require('../models/zonehSchema');
const router = require("express").Router();

//Get All User Records
router.get("/", async (req, res) => {
    try {
      const founds = await Zoneh.find();
      res.status(200).json(founds);
    } catch (err) {
      res.status(500).json(err);
    }
});

//Add New User to System
router.post("/addzoneh", async (req, res) => {

    const newRecord = new Zoneh({
    url: req.body.url,
    foundTime: req.body.foundTime,
    addTime: req.body.addTime,
    });

    try {
    const savedRecord = await newRecord.save();
    res.status(201).json(savedRecord);
    } catch (err) {
    res.status(500).json(err);
    }
});

module.exports = router;