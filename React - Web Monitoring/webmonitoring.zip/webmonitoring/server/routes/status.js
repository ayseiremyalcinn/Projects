const Status = require('../models/statusSchema');
const router = require("express").Router();

//Get All Status Records
router.get("/", async (req, res) => {
    try {
      const orders = await Status.find();
      res.status(200).json(orders);
    } catch (err) {
      res.status(500).json(err);
    }
});

module.exports = router;