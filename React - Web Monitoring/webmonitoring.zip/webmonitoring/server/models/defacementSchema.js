const mongoose = require('mongoose')
const Schema = mongoose.Schema

//The shchema that will be used in db
const defacementSchema = new Schema({
    url:{
        type: String,
        required: true,
        index : true
    },
    hash:{
        type:String,
        required:true,
        index:true
    },
    lastCheck:{
        type:String,
        index:true
    }
})

const Defacement = mongoose.model("Defacement", defacementSchema)
module.exports = Defacement;