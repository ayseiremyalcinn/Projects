const mongoose = require('mongoose')
const Schema = mongoose.Schema

//The shchema that will be used in db
const zonehSchema = new Schema({
    url:{
        type: String,
        required: true,
        index : true,
        
    },
    foundTime:{
        type:String,
        required:true,
    },
    addTime:{
        type:String,
        required:true,
    }
})

const Zoneh = mongoose.model("Zoneh", zonehSchema)
module.exports = Zoneh;