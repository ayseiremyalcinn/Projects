const mongoose = require('mongoose')
const Schema = mongoose.Schema

//The shchema that will be used in db
const hostSchema = new Schema({
    url:{
        type: String,
        required: true,
        index : true
    },
    subdomains:{
        type: Array,
        required: true,
        default: []
    },
    sslExpiration:{
        type:Number,
        required:true
    },
    sslLastCheck:{
        type:String,
        index:true
    }
})

const Host = mongoose.model("Host", hostSchema)
module.exports = Host;