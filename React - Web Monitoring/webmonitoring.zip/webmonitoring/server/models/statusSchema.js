const mongoose = require('mongoose')
const Schema = mongoose.Schema

//The shchema that will be used in db
const statusSchema = new Schema({
    url:{
        type: String,
        required: true,
        index : true
    },
    time:{
        type: String,
        index: true,
    },
    serverStatus:{
        type: Number,
        default: 500
    },
    responseTimes:{
        type:Array,
        default:[]
    }

})

const Status = mongoose.model("Status", statusSchema)
module.exports = Status;