const express = require('express');
const https = require('https');
const cors = require('cors');
const http = require('http');
const mongoose = require('mongoose')
const app = express();

const nodemailer = require('nodemailer');
const sslChecker = require('ssl-checker');
const {spawn} = require('child_process');
const fs = require('fs')

const Status = require('./models/statusSchema');
const Host = require('./models/hostSchema');
const User = require('./models/userSchema');
const Defacement = require('./models/defacementSchema');
const Zoneh = require('./models/zonehSchema');

const statusRoute = require("./routes/status");
const hostRoute = require("./routes/host");
const userRoute = require("./routes/user");
const defacementRoute = require("./routes/defacement");


//Mail Send Function
function sendMail(host, status, msubject){

    var transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
          user: 'gurkansoylu@sabanciuniv.edu',
          pass: 'tsoyluhsoylugsoylu123+'
        }
    });

    var mailOptions = {
        from: 'gurkansoylu@sabanciuniv.edu',
        to: 'grsylu14@gmail.com',
        subject: msubject,
        text: status
    };

    transporter.sendMail(mailOptions, function(error, info){
        if (error) {
          console.log(error);
        } else {
          console.log('Email sent: ' + info.response);
        }
      });
}

//SSL Check Function
async function checkSSL(){
    try{

        const hosts = await Host.find();

        if(hosts != null){
            hosts.forEach((host)=>{
                if(host.url.includes("https")){
                    sslChecker(host.url.replace("https://","").replace("/",""), { method: "GET", port: 443 })
                    .then((info) =>{
                        Host.findOneAndUpdate({url:host.url},{sslExpiration:info.daysRemaining, sslLastCheck:Date().toString()}, function(err,docs){})
                        console.log(host.url + " " + info.daysRemaining)
                        if(info.daysRemaining < 45){
                            sendMail(host.url, "BE CAREFUL! Your SSL Certificate Has " + info.daysRemaining.toString() + " Days Left!",host.url+" SSL Status")
                        }
                        else if(info.daysRemaining < 90){
                            sendMail(host.url, "Remainder: Your SSL Certificate Has " + info.daysRemaining.toString() + " Days Left!",host.url+" SSL Status")
                        }
                    });
                }
                else{
                    sendMail(host.url, "ALERT!!! "+ host.url + " HAS NO SSL CERTIFICATE." ,host.url+" SSL Status")
                }
            })
        }

        console.log("")
    }
    catch(err){
        console.log(err)
    }
}

function suddenCheck(){

    var start = new Date();
    https.get("https://www.izmir.bel.tr/", 
        function(){
            console.log('Request took:', new Date() - start, 'ms');
        }).on('error', function(e){
        })
}

//Website Health Check Function
async function checkHealth()  {
    try {

        const hostList = await Host.find();
        const userList = await User.find();
        //Sending HTTPS Request to Each Host
        hostList.forEach((aHost) => {

            let site = aHost.url

            if(site.includes("https")){
                
                let start = new Date();
                //Https request to host
                https.get(site, 
                function(res){
                if( res.statusCode >= 200 && res.statusCode <= 399 ){

                    //Print status to Console
                    let responseTime = new Date() - start
                    console.log('Request took:', responseTime , 'ms');
                    console.log(site + " Up and Running ");

                    //Get the last status of host
                    Status.findOne({url:site}, function(err, doc) { 
                        if(doc === null){
                            const stts = {
                                url: site,
                                serverStatus: res.statusCode,
                                time:Date().toString(),
                                responseTimes: [{time: start.toString().replace("GMT+0300 (GMT+03:00)", "") , duration:responseTime}]
                            }
        
                            const webstatus = new Status(stts)
                            webstatus.save()
                        }
                        else if( doc.serverStatus >= 200 && doc.serverStatus <= 399 ){


                            let responseList = doc.responseTimes
                            responseList.push({time: start.toString().replace("GMT+0300 (GMT+03:00)", "") , duration:responseTime})
                            Status.deleteOne({url:site},function(err){})
                            

                            const stts = {
                                url: site,
                                serverStatus: res.statusCode,
                                time:Date().toString(),
                                responseTimes:responseList
                            }

                            const webstatus = new Status(stts)
                            webstatus.save()
                        }
                        else{

                            let responseList = doc.responseTimes
                            responseList.push({time: start.toString().replace("GMT+0300 (GMT+03:00)", "") , duration:responseTime})
                            Status.deleteOne({url:site},function(err){})
                            
                            const stts = {
                                url: site,
                                serverStatus: res.statusCode,
                                time:Date().toString(),
                                responseTimes:responseList
                            }

                            const webstatus = new Status(stts)
                            webstatus.save()
                            //Send Mail About The Error
                            let message = site + " IS NOW UP AND RUNNING!!!"
                            sendMail(site, message, site+" Status")
                        }
                    });
                } 
                else if(res.statusCode >= 500 && res.statusCode < 599){


                    let responseTime = new Date() - start

                    //Get the last status of host
                    Status.findOne({url:site}, function(err, doc) {
                        if(doc === null){
                            const stts = {
                                url: site,
                                serverStatus: res.statusCode,
                                time:Date(),
                                responseTimes:[{time: start.toString().replace("GMT+0300 (GMT+03:00)", "") , duration:responseTime}]
                            }
        
                            //Send Mail About The Error
                            let message = site + " IS DOWN!!!"
                            sendMail(site, message,site+" Status")

                            const webstatus = new Status(stts)
                            webstatus.save()
                        } 
                        else if( doc.serverStatus >= 200 && doc.serverStatus <= 399 ){

                            let responseList = doc.responseTimes
                            responseList.push({time: start.toString().replace("GMT+0300 (GMT+03:00)", "") , duration:responseTime})
                            Status.deleteOne({url:site},function(err){})

                            const stts = {
                                url: site,
                                serverStatus: res.statusCode,
                                time:Date(),
                                responseTimes: responseList
                            }

                            const webstatus = new Status(stts)
                            webstatus.save()

                            //Send Mail About The Error
                            let message = site + " IS DOWN!!!"
                            sendMail(site, message,site+" Status")
                        }
                        else if(res.statusCode >= 500 && res.statusCode < 599){
                            const lastCheckTime = Date.parse(doc.time)
                            const difference = Date.now()-lastCheckTime

                            if(difference/1000 < 60){
                                let message = site + " IS DOWN FOR " + (difference/1000).toString() + " SECONDS!!!"
                                sendMail(site, message,site+" Status")
                            }
                            else{
                                let message = host + " IS DOWN FOR " + Math.floor(difference/60000).toString() + " MINUTES AND " 
                                + (difference%60000).toString() + " SECONDS!!!"
                                sendMail(site, message,site+" Status")                            
                            }
                        }
                    });
                }
                }).on('error', function(e){
                    let responseList = doc.responseTimes
                    responseList.push({time: start.toString().replace("GMT+0300 (GMT+03:00)", "") , duration:responseTime})
                    Status.deleteOne({url:site},function(err){})

                    const stts = {
                        url: site,
                        serverStatus: Math.abs(e.errno),
                        time:Date(),
                        responseTimes:responseList
                    }

                    const webstatus = new Status(stts)
                    webstatus.save()

                    //Send Mail About The Error
                    let message = site + " CANNOT REACH WEBSITE!!!"
                    sendMail(site, message,site+" Status")
                    console.log(site)
                    console.log(e);
                })
            }
            else {
                
                let start = new Date();
                //Http request to host
                http.get(site, 
                function(res){
                if( res.statusCode >= 200 && res.statusCode <= 399 ){

                    //Print status to Console
                    let responseTime = new Date() - start
                    console.log('Request took:', responseTime , 'ms');
                    console.log(site + " Up and Running ");

                    //Get the last status of host
                    Status.findOne({url:site}, function(err, doc) { 
                        if(doc === null){
                            const stts = {
                                url: site,
                                serverStatus: res.statusCode,
                                time:Date().toString(),
                                responseTimes: [{time: start.toString().replace("GMT+0300 (GMT+03:00)", "") , duration:responseTime}]
                            }
        
                            const webstatus = new Status(stts)
                            webstatus.save()
                        }
                        else if( doc.serverStatus >= 200 && doc.serverStatus <= 399 ){


                            let responseList = doc.responseTimes
                            responseList.push({time: start.toString().replace("GMT+0300 (GMT+03:00)", "") , duration:responseTime})
                            Status.deleteOne({url:site},function(err){})
                            

                            const stts = {
                                url: site,
                                serverStatus: res.statusCode,
                                time:Date().toString(),
                                responseTimes:responseList
                            }

                            const webstatus = new Status(stts)
                            webstatus.save()
                        }
                        else{

                            let responseList = doc.responseTimes
                            responseList.push({time: start.toString().replace("GMT+0300 (GMT+03:00)", "") , duration:responseTime})
                            Status.deleteOne({url:site},function(err){})
                            
                            const stts = {
                                url: site,
                                serverStatus: res.statusCode,
                                time:Date().toString(),
                                responseTimes:responseList
                            }

                            const webstatus = new Status(stts)
                            webstatus.save()
                            //Send Mail About The Error
                            let message = site + " IS NOW UP AND RUNNING!!!"
                            sendMail(site, message, site+" Status")
                        }
                    });
                } 
                else if(res.statusCode >= 500 && res.statusCode < 599){


                    let responseTime = new Date() - start

                    //Get the last status of host
                    Status.findOne({url:site}, function(err, doc) {
                        if(doc === null){
                            const stts = {
                                url: site,
                                serverStatus: res.statusCode,
                                time:Date(),
                                responseTimes:[{time: start.toString().replace("GMT+0300 (GMT+03:00)", "") , duration:responseTime}]
                            }
        
                            //Send Mail About The Error
                            let message = site + " IS DOWN!!!"
                            sendMail(site, message,site+" Status")

                            const webstatus = new Status(stts)
                            webstatus.save()
                        } 
                        else if( doc.serverStatus >= 200 && doc.serverStatus <= 399 ){

                            let responseList = doc.responseTimes
                            responseList.push({time: start.toString().replace("GMT+0300 (GMT+03:00)", "") , duration:responseTime})
                            Status.deleteOne({url:site},function(err){})

                            const stts = {
                                url: site,
                                serverStatus: res.statusCode,
                                time:Date(),
                                responseTimes: responseList
                            }

                            const webstatus = new Status(stts)
                            webstatus.save()

                            //Send Mail About The Error
                            let message = site + " IS DOWN!!!"
                            sendMail(site, message,site+" Status")
                        }
                        else if(res.statusCode >= 500 && res.statusCode < 599){
                            const lastCheckTime = Date.parse(doc.time)
                            const difference = Date.now()-lastCheckTime

                            if(difference/1000 < 60){
                                let message = site + " IS DOWN FOR " + (difference/1000).toString() + " SECONDS!!!"
                                sendMail(site, message,site+" Status")
                            }
                            else{
                                let message = host + " IS DOWN FOR " + Math.floor(difference/60000).toString() + " MINUTES AND " 
                                + (difference%60000).toString() + " SECONDS!!!"
                                sendMail(site, message,site+" Status")                            
                            }
                        }
                    });
                }
                }).on('error', function(e){
                    let responseList = doc.responseTimes
                    responseList.push({time: start.toString().replace("GMT+0300 (GMT+03:00)", "") , duration:responseTime})
                    Status.deleteOne({url:site},function(err){})

                    const stts = {
                        url: site,
                        serverStatus: Math.abs(e.errno),
                        time:Date(),
                        responseTimes: responseList
                    }

                    const webstatus = new Status(stts)
                    webstatus.save()

                    //Send Mail About The Error
                    let message = site + " CANNOT REACH WEBSITE!!!"
                    sendMail(site, message,site+" Status")
                    console.log(site)
                    console.log(e);
                })
            }
            console.log("")
        })
    }
    catch (error) {
        console.log(error)
    }
}

//Website Defacement Check Function
async function checkDefacement(){

    const defacementList = await Defacement.find();
    const userList = await User.find();

}

//ZoneH Parser Script Caller Python
async function checkZoneH(){ 
    const pythonChild = spawn('python', ["ZoneH.py"])
}

app.use(cors())
app.use(express.json());

//Routes for our server
app.get("/", function(req, res){
    res.send("<h2>Server is running on port 3001</h2>")
})

app.get("/health", function(req, res){
    res.send('<h2>Website health check is on</h2>')
    checkHealth();   
})

app.get("/sslCheck", function(req, res){
    res.send('<h2>Website ssl check is on</h2>')
    checkSSL()
})

app.get("/defacementCheck", function(req, res){
    res.send('<h2>Website defacement check is on</h2>')
    checkDefacement()
})

app.get("/suddenCheck", function(req, res){
    res.send('<h2>Website sudden check is on</h2>')
    suddenCheck()
})

app.get("/checkZoneH", async function (req,res){
    res.send("<h2>ZoneH check is on</h2>")
    await checkZoneH()
    fs.readFile('C:\\Users\\lenovo\\intrusiondetection\\found.txt', 'utf8', (err, data) => {
        if (err) {
          console.error(err);
          return;
        }
        data.split("\r\n").forEach((site)=>{
            
            const znh = {
                url: site,
                foundTime: new Date().toString(),
                addTime: "-"
            }
            const zonehStatus = new Zoneh(znh)
            zonehStatus.save()
        })
    });
})

//Database Routes
app.use("/status", statusRoute);
app.use("/host", hostRoute);
app.use("/user", userRoute);
app.use("/defacement", defacementRoute);

//URI for mongodb
const mongoURI = "mongodb+srv://grsylu:fr68TsTQNwFEzPoL@statusdb.3aqhb.mongodb.net/?retryWrites=true&w=majority"

//Connecting mongodb
mongoose.connect(mongoURI, function(){console.log("Connected to database")})

//Running the server
app.listen(3001 ,function(){console.log("Server started on port 3001")})

//Calling the health check function asynchronously
function healthCheckAsync(){
    return new Promise((res, rej)=>{
      setTimeout(()=>{
        checkHealth()
        res()
      }, 1000*60*10)
    })
}
  
(async () => {
    while(true) await healthCheckAsync()
})()

//Calling the ssl expiration check function asynchronously
function sslCheckAsync(){
    return new Promise((res, rej)=>{
      setTimeout(()=>{
        checkSSL()
        res()
      }, 1000*60*60)
    })
}

(async () => {
    while(true) await sslCheckAsync()
})()

//Calling the defacement check function asynchronously
function defacementCheckAsync(){
    return new Promise((res, rej)=>{
      setTimeout(()=>{
        checkDefacement()
        res()
      }, 1000*60*60)
    })
}

(async () => {
    while(true) await defacementCheckAsync()
})()
