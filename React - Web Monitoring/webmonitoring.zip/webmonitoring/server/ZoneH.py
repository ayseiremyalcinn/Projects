from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium. webdriver. chrome. options import Options
from selenium.webdriver.common.by import By
from fake_useragent import UserAgent
import numpy as np

chrome_options = Options()

ua = UserAgent()
userAgent = ua.random
chrome_options.add_argument(f'user-agent={userAgent}')
chrome_options.add_experimental_option("detach", True)

driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options = chrome_options)
driver.delete_all_cookies()

url = "http://www.zone-h.org/archive/special=1/page="
govermental = []

for i in range(50):

    driver.get(url+str(i))
    content = driver.page_source
    objects = driver.find_elements(By.TAG_NAME, "td")

    for item in objects:
        if (".gov.tr" in item.text) or (".bel.tr" in item.text):
            govermental.append(item.text)

    """
    group_objects = np.array_split(objects, 10)
    for item in group_objects:
        for i in item:
            print(i.text, end='')
        print("\n")
    """
    
driver.close()

with open('found.txt', 'w') as f:
    for site in govermental:
        f.write(site)
        f.write('\n')

print(govermental)